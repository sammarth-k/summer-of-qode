num = int(input("enter number: "))
if (num>0) and (num<11):
  print ("your number falls in our range of 1 to 10")
else:
  print ("sorry your number does not fall in our range pls try again")