age = int(input("Enter age: "))
print(100-age , "years till you turn 100")
