price_first_shop = 15
price_second_shop = 30
items_first_shop = int(
    input("How many tea cups will you buy from the first shop?: "))
items_second_shop = int(
    input("How many tea cups will you buy from the second shop?: "))
items_second_shop = 3
items_first_shop = 5
bill = (items_first_shop * price_first_shop) + (items_second_shop *
                                                price_second_shop)
print(
    "......................................................\n"
    "Your bill is: ", bill)