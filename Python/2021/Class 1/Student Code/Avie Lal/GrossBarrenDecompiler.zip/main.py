Tea1 = input('Tea from shop one =\n')
Tea1 = int(Tea1)
Tea1 = Tea1*15
T2 = input('Tea from shop 2 =\n')
T2 = int(T2)
T2 = T2*30
Tea_total = Tea1 + T2;
print("Total bill =",Tea_total," Rupees")