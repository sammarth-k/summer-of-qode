#Randomly select 5 elements of a list using their index (donot userandom.choice()). Then, check for duplicate values.Hint: ****use the.count() method.
import random


list1 =  ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16","17", "18", "19", "20"]


random_list1 =  [ ]
count = 0
while count < random.randrange(0,20):
  count += 1
  random_list1.append(list1[random.randint(0, len(list1) - 1)])
print(random_list1, "is the random array")


count += 0
final = [ ]
while count< 4 :
  count += 1
  random_num = random.randint(0, len(random_list1) -1)
  final.append(random_list1[random_num])

duplicates = []
print(final, "these are the 5 random numbers from the array")
for i in random_list1:

    if random_list1.count(i) >1:
        duplicates.append(i)
print(duplicates, "are the duplicates")



    

