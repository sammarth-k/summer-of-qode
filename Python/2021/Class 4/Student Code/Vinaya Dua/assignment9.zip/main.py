
import random

num = random.randint (1,10)
count = 0
while count < 3:
  num2 = int(input("enter your guess for the number:"))
  count += 1
  won = False
  if num2 == num:
    print("You guessed it right!")
    won = True
    break

if won == False:
  print("Try again!")

  








