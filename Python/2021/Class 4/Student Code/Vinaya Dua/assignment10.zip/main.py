

#Randomly select 5 elements of a list using their index (donot userandom.choice()). Then, check for duplicate values.Hint: ****use the.count() method.

import random

user_action = input("enter your choice, (rock, paper, scissors):" )

possible_actions = ("rock", "paper", "scissors")
computer = random.choice(possible_actions)
print("your turn" , {user_action }, "computers turn",{computer} )

if user_action == computer:
  print("Its a tie")
elif user_action == "rock":
  if computer == "scissors":
    print("rock smashes scissors, you win!")
  else:
    print("paper covers rock, you lose")
elif user_action == "scissors":
  if computer == "paper":
    print("scissors cut paper, you win!")
  else:
    print("rock smashes scissors, you lose")
elif user_action == "paper":
  if computer == "rock":
    print("paper covers rock, you win!")
  else:
    print("rock smashes scissors, you lose")
print("game over")





