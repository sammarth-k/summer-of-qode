variable = int(input("enter number: "))
if (variable % 2) == 0:
  print ("this number is even")
else:
  print ("this number is odd")