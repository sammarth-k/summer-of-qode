print ("Assignment 1")
print ("odd or even?")
import Assignment_1

print ("Assignment 2")
print ("how many chocolates would you like?")
import Assignment_2

print ("Final Assignment, Assignment 3")
print ("we will figure out if your given number falls in our range")
import Assignment_3


